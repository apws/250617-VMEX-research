//sally-messages.h


void MessageWrite(const TChar *msgPtr);
void MessageWriteLn(const TChar *msgPtr);


static const TChar msg_init[]          PROGMEM = "\n\nSALLY" PLATFORM_32 VERSION ;
static const TChar msg_memory[]        PROGMEM = " bytes free.";

static const TChar msg_ok[]            PROGMEM = "OK";
static const TChar msg_what[]          PROGMEM = "What? ";
static const TChar msg_how[]           PROGMEM = "How?";
static const TChar msg_sorry[]         PROGMEM = "Sorry!";

static const TChar msg_break[]         PROGMEM = "break!";

//static const TChar msg_unimplimented[] PROGMEM = "Unimplemented";
//static const TChar msg_backspace[]     PROGMEM = "\b \b";


void MessageWrite(const TChar *msgPtr)
{
    while (pgm_read_byte(msgPtr) != 0)
    {
        ConsoleOutput( pgm_read_byte(msgPtr++) );
    };
}


void MessageWriteLn(const TChar *msgPtr)
{
    MessageWrite(msgPtr);
    WriteLn();
}

