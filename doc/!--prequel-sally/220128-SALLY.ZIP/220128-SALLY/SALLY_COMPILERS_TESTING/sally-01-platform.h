//sally-platform.h


//IDEA !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// #ifndef BUFFER_LENGTH
//   #if (RAMSIZE < 256)
//     #define BUFFER_LENGTH 16
//   #elif (RAMSIZE < 4096)
//     #define BUFFER_LENGTH 32
//   #else
//     #define BUFFER_LENGTH 130
//   #endif
// #endif 

//INFINEON cortex-m0 xmc1100 xmc2go board (commented by default) !!!!!!!!!!!!!!!!
//
//#define RAMSTART (HMCRAMC0_ADDR)
//#define RAMSIZE  (HMCRAMC0_SIZE)
//#define RAMEND   (RAMSTART + RAMSIZE - 1)
//

//SEEDUINO - adapted different cores !!!!!!!!!!!!!!!!!!!!!!!!!!
// #ifdef __SAMD51__
//   #define RAMSTART (HSRAM_ADDR)
//   #define RAMSIZE  (HSRAM_SIZE)
// #else
//   #define RAMSTART (HMCRAMC0_ADDR)
//   #define RAMSIZE  (HMCRAMC0_SIZE)
// #endif
// #define RAMEND   (RAMSTART + RAMSIZE - 1) 

// Use INTERNAL_SRAM_SIZE instead of RAMEND - RAMSTART, which is vulnerable to a fencepost error. 

#ifdef PLATFORM_32
    #define RAMSIZE (20000)
#else
    #define RAMSIZE (2000)
#endif

#ifdef PLATFORM_32
  #define PROGRAM_SIZE (RAMSIZE - 2400) 
#else
  #define PROGRAM_SIZE (RAMSIZE - 1200) //originally 1160
#endif

//STM32 compiler has menu options for OPTIMIZATIONS !!!
//with uploading via SWD STM32 WORKS !!!
//may be try FAST+LTO ???

// Enable memory alignment for 32bit processors
#ifdef PLATFORM_32
    #define ALIGN_MEMORY //required and works on NodeMCU and stm32g031-nucleo-32 !!!
#endif

#ifdef ALIGN_MEMORY
    // Align memory addess x to an even page
    #define ALIGN_UP(x) ((TU8 *)(((TU32)((x) + 1) >> 1) << 1))
    #define ALIGN_DOWN(x) ((TU8 *)(((TU32)(x) >> 1) << 1))
#else
    #define ALIGN_UP(x) x
    #define ALIGN_DOWN(x) x
#endif

// Use pgmspace/PROGMEM directive to store strings in progmem to save RAM
//#include <avr/pgmspace.h>

// some catches for AVR based text string stuff...
#ifndef PROGMEM
    #define PROGMEM
#endif
#ifndef pgm_read_byte
    #define pgm_read_byte(flash) *(flash)
#endif

#define VAR_SIZE sizeof(TS16) // Size of variables in bytes
