//sally-chars.h

//syntax characters
static const TChar SPACE = ' ';
static const TChar NEWLINE = '\n';
static const TChar SINGLE_QUOTE = '\'';
static const TChar DOUBLE_QUOTE = '\"';
static const TChar DIRECT_PROMPT = '>';
static const TChar INPUT_PROMPT = '?';
static const TChar ASSIGN = '=';
static const TChar WHAT_POINTER = '^';
static const TChar CMD_DELIMITER = ':';
static const TChar ARG_DELIMITER = ',';
static const TChar PNL_DELIMITER = ';'; //only print - remove, make cmd print, println !!!


//control characters (terminal)
static const TChar CR = '\r'; //single use (read.h ReadLine() - support PASTING OF LIST !!!)
//static const TChar LF = 0x0a;
//static const TChar TAB = '\t';
static const TChar BELL = '\b';
static const TChar CTRLC = 0x03;
//#define CTRLH	0x08
//#define CTRLS	0x13
//#define CTRLX	0x18

