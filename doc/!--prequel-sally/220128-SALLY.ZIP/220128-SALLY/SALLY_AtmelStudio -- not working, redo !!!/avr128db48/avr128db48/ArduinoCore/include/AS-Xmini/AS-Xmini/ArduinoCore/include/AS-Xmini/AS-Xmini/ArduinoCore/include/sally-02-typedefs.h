//sally-typedefs.h


//FORCED MIXWORX TYPES
typedef boolean TBool;
typedef char TChar;
typedef char TS8;
typedef unsigned char TU8;
typedef short int TS16;
typedef unsigned short int TU16;
//typedef int TS32;
typedef unsigned int TU32;

static const TU16 TU16_MAX = 0xFFFFu;

//sally types
typedef TU16 TLineNum_U16;


