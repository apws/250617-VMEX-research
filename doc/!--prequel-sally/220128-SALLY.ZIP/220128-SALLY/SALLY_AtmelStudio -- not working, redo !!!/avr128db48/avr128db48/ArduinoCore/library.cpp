/*
 * ArduinoCore.cpp
 *
 * Created: 2022-02-02 03:34:54
 * Author : petra
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

