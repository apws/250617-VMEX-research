//sally-expressions.h


static TS16 Expr4(void);
static TS16 Expr3(void);
static TS16 Expr2(void);
static TS16 ParseExpression(void);


static TS16 Expr4(void)
{
    // fix provided by Jurg Wullschleger wullschleger@gmail.com
    // fixes whitespace and unary operations
    ParseWhitespace();

    if (*gsPositionPtr == '-')
    {
        gsPositionPtr++;
        return -Expr4();
    }
    // end fix

    if (*gsPositionPtr == '0')
    {
        gsPositionPtr++;
        return false;
    }

    if (*gsPositionPtr >= '1' && *gsPositionPtr <= '9')
    {
        TS16 a = 0;
        do
        {
            a = a*10 + *gsPositionPtr - '0';
            gsPositionPtr++;
        }
        while (*gsPositionPtr >= '0' && *gsPositionPtr <= '9');
        return a;
    }

    // Is it a function or variable reference?
    if (gsPositionPtr[0] >= 'A' && gsPositionPtr[0] <= 'Z')
    {
        TS16 a;
        // Is it a variable reference (single alpha)
        if (gsPositionPtr[1] < 'A' || gsPositionPtr[1] > 'Z')
        {
            a = ((TS16 *)gsVarBeginPtr)[*gsPositionPtr - 'A'];
            gsPositionPtr++;
            return a;
        }

        // Is it a function with a single parameter
        ScanTableIndex(TABLE_FUNCTIONS);
        if (gsTableIndex == FUNC_UNKNOWN)
            goto expr4_error;

        TU8 func = gsTableIndex;

        if (*gsPositionPtr != '(')
            goto expr4_error;

        gsPositionPtr++;
        a = ParseExpression();
        if (*gsPositionPtr != ')')
            goto expr4_error;

        gsPositionPtr++;

        switch (func)
        {
          case FUNC_ABS:
              if (a < 0)
                  return -a;
              return a;

          case FUNC_RND:
              return(random(a));


          case FUNC_LIB_AREAD:
              pinMode(a, INPUT);
              return analogRead(a);

          case FUNC_LIB_DREAD:
              pinMode(a, INPUT);
              return digitalRead(a);

        }
    }

    if (*gsPositionPtr == '(')
    {
        TS16 a;
        gsPositionPtr++;
        a = ParseExpression();
        if (*gsPositionPtr != ')')
            goto expr4_error;

        gsPositionPtr++;
        return a;
    }

  expr4_error:
    gsExpressionError = true;
    return false;

}


static TS16 Expr3(void)
{
    TS16 a,b;

    a = Expr4();

    ParseWhitespace(); // fix for eg:  100 a = a + 1

    while (true)
    {
        if (*gsPositionPtr == '*')
        {
            gsPositionPtr++;
            b = Expr4();
            a *= b;
        }
        else if (*gsPositionPtr == '/')
        {
            gsPositionPtr++;
            b = Expr4();
            if (b != 0)
                a /= b;
            else
                gsExpressionError = true;
        }
        else
            return a;
    }
}


static TS16 Expr2(void)
{
    TS16 a,b;

    if (*gsPositionPtr == '-' || *gsPositionPtr == '+')
        a = 0;
    else
        a = Expr3();

    while (true)
    {
        if (*gsPositionPtr == '-')
        {
            gsPositionPtr++;
            b = Expr3();
            a -= b;
        }
        else if (*gsPositionPtr == '+')
        {
            gsPositionPtr++;
            b = Expr3();
            a += b;
        }
        else
            return a;
    }
}


static TS16 ParseExpression(void)
{
    TS16 a,b;

    a = Expr2();

    // Check if we have an error
    if (gsExpressionError) return a;

    ScanTableIndex(TABLE_RELOP);
    if (gsTableIndex == RELOP_UNKNOWN)
        return a;

    switch (gsTableIndex)
    {
      case RELOP_GE:
          b = Expr2();
          if (a >= b) return true;
          break;

      case RELOP_NE:
      case RELOP_NE_BANG:
          b = Expr2();
          if (a != b) return true;
          break;

      case RELOP_GT:
          b = Expr2();
          if (a > b) return true;
          break;

      case RELOP_EQ:
          b = Expr2();
          if (a == b) return true;
          break;

      case RELOP_LE:
          b = Expr2();
          if (a <= b) return true;
          break;

      case RELOP_LT:
          b = Expr2();
          if (a < b) return true;
          break;
    }
    return false;
}
