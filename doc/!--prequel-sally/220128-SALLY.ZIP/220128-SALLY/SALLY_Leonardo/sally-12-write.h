//sally-write.h


void WriteNumber(TS16 num);
void WriteUnsignedNumber(TU16 num);
static TBool IsWriteQuotedString(void);
void WriteLine();


void WriteNumber(TS16 num)
{
    TU8 digits = 0;

    if (num < 0)
    {
        num = -num;
        ConsoleOutput('-');
    }
    do
    {
        PushByte(num%10+'0');
        num = num/10;
        digits++;
    }
    while (num > 0);

    while (digits > 0)
    {
        ConsoleOutput(PopByte());
        digits--;
    }
}


void WriteUnsignedNumber(TU16 num)
{
    TU8 digits = 0;

    do
    {
        PushByte(num%10+'0');
        num = num/10;
        digits++;
    }
    while (num > 0);

    while (digits > 0)
    {
        ConsoleOutput(PopByte());
        digits--;
    }
}


static TBool IsWriteQuotedString(void)
{
    TU8 i=0;
    TU8 delim = *txtpos;
    if (delim != '"' && delim != '\'')
        return false;
    txtpos++;

    // Check we have a closing delimiter
    while (txtpos[i] != delim)
    {
        if (txtpos[i] == NL)
            return false;
        i++;
    }

    // Print the characters
    while (*txtpos != delim)
    {
        ConsoleOutput(*txtpos);
        txtpos++;
    }
    txtpos++; // Skip over the last delimiter

    return true;
}


void WriteLine()
{
    TU16_LineNum line_num;

    line_num = *((TU16_LineNum *)(list_line));
    list_line += sizeof(TU16_LineNum) + sizeof(TU8);

    // Output the line */
    WriteNumber(line_num);
    ConsoleOutput(' ');
    while (*list_line != NL)
    {
        ConsoleOutput(*list_line);
        list_line++;
    }
    list_line++;

#ifdef ALIGN_MEMORY
    // Start looking for next line on even page
    if (ALIGN_UP(list_line) != list_line)
        list_line++;
#endif

    WriteLn();
}
