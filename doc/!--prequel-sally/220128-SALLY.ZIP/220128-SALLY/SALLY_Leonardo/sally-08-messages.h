//sally-messages.h


void MessageWrite(const TChar *msg);
void MessageWriteLn(const TChar *msg);


static const TChar msg_ok[]            PROGMEM = "OK";
static const TChar msg_what[]          PROGMEM = "What? ";
static const TChar msg_how[]           PROGMEM = "How?";
static const TChar msg_sorry[]         PROGMEM = "Sorry!";
static const TChar msg_init[]          PROGMEM = "sally " VERSION;
static const TChar msg_memory[]        PROGMEM = " bytes free.";
static const TChar msg_break[]         PROGMEM = "break!";
//static const TChar msg_unimplimented[] PROGMEM = "Unimplemented";
static const TChar msg_backspace[]     PROGMEM = "\b \b";


void MessageWrite(const TChar *msg)
{
    while (pgm_read_byte( msg ) != 0)
    {
        ConsoleOutput( pgm_read_byte( msg++ ) );
    };
}


void MessageWriteLn(const TChar *msg)
{
    MessageWrite(msg);
    WriteLn();
}

