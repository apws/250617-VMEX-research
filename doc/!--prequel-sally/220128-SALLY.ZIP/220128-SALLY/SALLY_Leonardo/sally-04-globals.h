//sally-globals.h

static TU8 program[PROGRAM_SIZE];
static const TChar *sentinel = "HELLO";
static TU8 *txtpos, *list_line, *tmp_txtpos;
static TU8 *tempsp;

static TBool expression_error;

static TU8 *stack_limit;
static TU8 *program_start;
static TU8 *program_end;
static TU8 *variables_begin;
static TU8 *current_line;
static TU8 *sp;


static TU8 table_index;
static TU16_LineNum linenum;


TBool inhibitOutput = false;
static TBool triggerRun = false;

// these will select, at runtime, where IO happens through for load/save
enum {
    kStreamSerial = 0,
    kStreamEEProm,
    kStreamFile
};
static TU8 inStream = kStreamSerial;
