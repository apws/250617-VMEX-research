//sally-stack.h


static void PushByte(TU8 b);
static TU8 PopByte();


#define STACK_DEPTH 5
#define STACK_SIZE (sizeof(struct StackFrame_FOR) * STACK_DEPTH)

struct StackFrame_FOR {
    TChar frame_type;
    TChar for_var;
    TS16 terminal;
    TS16 step;
    TU8 *current_line;
    TU8 *txtpos;
};
#define STACK_FOR_FLAG 'F'


struct StackFrame_GOSUB {
    TChar frame_type;
    TU8 *current_line;
    TU8 *txtpos;
};
#define STACK_GOSUB_FLAG 'G'


static void PushByte(TU8 b)
{
    sp--;
    *sp = b;
}


static TU8 PopByte()
{
    TU8 b;
    b = *sp;
    sp++;
    return b;
}
