//sally-read.h

static void ReadLine(TChar prompt)
{
    ConsoleOutput(prompt);
    txtpos = program_end+sizeof(TU16_LineNum);

    while (true)
    {
        TChar c = ConsoleInput();
        switch (c)
        {
          case NL:
              //break;

          case CR:
              WriteLn();
              // Terminate all strings with a NL
              txtpos[0] = NL;
              return;

          // case CTRLH:
          //     if (txtpos == program_end)
          //         break;
          //     txtpos--;
          //     MessageWriteLn(msg_backspace);
          //     break;

          default:
              // We need to leave at least one space to allow us to shuffle the line into order
              if (txtpos == variables_begin-2)
                  ConsoleOutput(BELL);
              else
              {
                  txtpos[0] = c;
                  txtpos++;
                  ConsoleOutput(c);
              }
        }
    }
}

