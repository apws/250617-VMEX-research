//sally-console.h


static TBool IsConsoleBreak(void);
static TChar ConsoleInput();
static void ConsoleOutput(TChar c);
static void WriteLn(void);


static TBool IsConsoleBreak(void)
{
  if (Serial.available())
    return Serial.read() == CTRLC;
  return false;
}


static TChar ConsoleInput()
{
    switch (inStream)
    {
      case kStreamFile:
          break;

      case kStreamEEProm:
          break;

      case kStreamSerial:
      default:
          while (true)
          {
              if (Serial.available())
                  return Serial.read();
          }
      }

    inStream = kStreamSerial;
    inhibitOutput = false;

    return NL; // trigger a prompt.
}


static void ConsoleOutput(TChar c)
{
  if (inhibitOutput) return;
  Serial.write(c);
}


static void WriteLn(void)
{
  ConsoleOutput(NL);
  //ConsoleOutput(CR); //mixworx
}

