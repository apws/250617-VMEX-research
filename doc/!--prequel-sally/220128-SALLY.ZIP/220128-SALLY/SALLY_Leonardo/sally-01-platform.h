//sally-platform.h

#define VERSION "v0.21" //modified for ARDUINO ONLY, SIMPLIFIED IFDEFS

//Termite serial terminal needs RTS/CTS for Leonardo, otherwise NONE
#define CONSOLE_BAUD 115200 // ConsoleInput, ConsoleOutput

#ifndef RAMSIZE
     #define RAMSIZE (2000)
#endif

#define PROGRAM_SIZE (RAMSIZE - 1160)

// Enable memory alignment for 32bit processors
//#define ALIGN_MEMORY 0
#undef ALIGN_MEMORY
#ifdef ALIGN_MEMORY
    // Align memory addess x to an even page
    #define ALIGN_UP(x) ((TU8 *)(((TU32)((x) + 1) >> 1) << 1))
    #define ALIGN_DOWN(x) ((TU8 *)(((TU32)(x) >> 1) << 1))
#else
    #define ALIGN_UP(x) x
    #define ALIGN_DOWN(x) x
#endif

// Use pgmspace/PROGMEM directive to store strings in progmem to save RAM
//#include <avr/pgmspace.h>

// some catches for AVR based text string stuff...
#ifndef PROGMEM
    #define PROGMEM
#endif
#ifndef pgm_read_byte
    #define pgm_read_byte(A) *(A)
#endif

#define VAR_SIZE sizeof(TS16) // Size of variables in bytes

