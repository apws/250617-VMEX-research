//sally-typedefs.h


//FORCED MIXWORX TYPES
typedef boolean TBool;
typedef char TChar;
typedef char TS8;
typedef unsigned char TU8;
typedef short int TS16;
typedef unsigned short int TU16;
typedef int TS32;
typedef unsigned int TU32;

//sally types
typedef TU16 TU16_LineNum;
