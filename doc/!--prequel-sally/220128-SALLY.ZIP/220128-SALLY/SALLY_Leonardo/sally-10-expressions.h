//sally-expressions.h


static TS16 Expr4(void);
static TS16 Expr3(void);
static TS16 Expr2(void);
static TS16 Expression(void);


static TS16 Expr4(void)
{
    // fix provided by Jurg Wullschleger wullschleger@gmail.com
    // fixes whitespace and unary operations
    SkipWhitespace();

    if (*txtpos == '-')
    {
        txtpos++;
        return -Expr4();
    }
    // end fix

    if (*txtpos == '0')
    {
        txtpos++;
        return false;
    }

    if (*txtpos >= '1' && *txtpos <= '9')
    {
        TS16 a = 0;
        do
        {
            a = a*10 + *txtpos - '0';
            txtpos++;
        }
        while (*txtpos >= '0' && *txtpos <= '9');
        return a;
    }

    // Is it a function or variable reference?
    if (txtpos[0] >= 'A' && txtpos[0] <= 'Z')
    {
        TS16 a;
        // Is it a variable reference (single alpha)
        if (txtpos[1] < 'A' || txtpos[1] > 'Z')
        {
            a = ((TS16 *)variables_begin)[*txtpos - 'A'];
            txtpos++;
            return a;
        }

        // Is it a function with a single parameter
        ScanTable(TABLE_FUNCTIONS);
        if (table_index == FUNC_UNKNOWN)
            goto expr4_error;

        TU8 f = table_index;

        if (*txtpos != '(')
            goto expr4_error;

        txtpos++;
        a = Expression();
        if (*txtpos != ')')
            goto expr4_error;

        txtpos++;

        switch (f)
        {
          case FUNC_ABS:
              if (a < 0)
                  return -a;
              return a;

          case FUNC_AREAD:
              pinMode( a, INPUT );
              return analogRead( a );

          case FUNC_DREAD:
              pinMode( a, INPUT );
              return digitalRead( a );

          case FUNC_RND:
              return( random( a ));
        }
    }

    if (*txtpos == '(')
    {
        TS16 a;
        txtpos++;
        a = Expression();
        if (*txtpos != ')')
            goto expr4_error;

        txtpos++;
        return a;
    }

  expr4_error:
    expression_error = true;
    return false;

}


static TS16 Expr3(void)
{
    TS16 a,b;

    a = Expr4();

    SkipWhitespace(); // fix for eg:  100 a = a + 1

    while (true)
    {
        if (*txtpos == '*')
        {
            txtpos++;
            b = Expr4();
            a *= b;
        }
        else if (*txtpos == '/')
        {
            txtpos++;
            b = Expr4();
            if (b != 0)
                a /= b;
            else
                expression_error = 1;
        }
        else
            return a;
    }
}


static TS16 Expr2(void)
{
    TS16 a,b;

    if (*txtpos == '-' || *txtpos == '+')
        a = 0;
    else
        a = Expr3();

    while (true)
    {
        if (*txtpos == '-')
        {
            txtpos++;
            b = Expr3();
            a -= b;
        }
        else if (*txtpos == '+')
        {
            txtpos++;
            b = Expr3();
            a += b;
        }
        else
            return a;
    }
}


static TS16 Expression(void)
{
    TS16 a,b;

    a = Expr2();

    // Check if we have an error
    if (expression_error) return a;

    ScanTable(TABLE_RELOP);
    if (table_index == RELOP_UNKNOWN)
        return a;

    switch (table_index)
    {
      case RELOP_GE:
          b = Expr2();
          if (a >= b) return true;
          break;

      case RELOP_NE:
      case RELOP_NE_BANG:
          b = Expr2();
          if (a != b) return true;
          break;

      case RELOP_GT:
          b = Expr2();
          if (a > b) return true;
          break;

      case RELOP_EQ:
          b = Expr2();
          if (a == b) return true;
          break;

      case RELOP_LE:
          b = Expr2();
          if (a <= b) return true;
          break;

      case RELOP_LT:
          b = Expr2();
          if (a < b) return true;
          break;
    }
    return false;
}
