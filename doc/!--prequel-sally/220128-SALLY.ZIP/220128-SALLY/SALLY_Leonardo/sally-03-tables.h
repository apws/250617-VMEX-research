//sally-tables.h

// Keyword table and constants - the last character has 0x80 added to it
static const TU8 TABLE_KEYWORDS[] PROGMEM = {
    'L','I','S','T'+0x80,
    'N','E','W'+0x80,
    'R','U','N'+0x80,
    'N','E','X','T'+0x80,
    'L','E','T'+0x80,
    'I','F'+0x80,
    'G','O','T','O'+0x80,
    'G','O','S','U','B'+0x80,
    'R','E','T','U','R','N'+0x80,
    'R','E','M'+0x80,
    'F','O','R'+0x80,
    'I','N','P','U','T'+0x80,
    'P','R','I','N','T'+0x80,
    'S','T','O','P'+0x80,
    'B','Y','E'+0x80,
    'M','E','M'+0x80,
    '?'+ 0x80,
    '\''+ 0x80,
    'A','W','R','I','T','E'+0x80,
    'D','W','R','I','T','E'+0x80,
    'D','E','L','A','Y'+0x80,
    'E','N','D'+0x80,
    'R','S','E','E','D'+0x80,
    0
};
// by moving the command list to an enum, we can easily remove sections
// above and below simultaneously to selectively obliterate functionality.
enum {
    KW_LIST = 0,
    KW_NEW, KW_RUN,
    KW_NEXT, KW_LET, KW_IF,
    KW_GOTO, KW_GOSUB, KW_RETURN,
    KW_REM,
    KW_FOR,
    KW_INPUT, KW_PRINT,
    KW_STOP, KW_BYE,
    KW_MEM,
    KW_QMARK, KW_QUOTE,
    KW_AWRITE, KW_DWRITE,
    KW_DELAY,
    KW_END,
    KW_RSEED,
    KW_DEFAULT /* always the final one*/
};


static const TU8 TABLE_FUNCTIONS[] PROGMEM = {
    'A','B','S'+0x80,
    'A','R','E','A','D'+0x80,
    'D','R','E','A','D'+0x80,
    'R','N','D'+0x80,
  0
};
#define FUNC_ABS     1
#define FUNC_AREAD   2
#define FUNC_DREAD   3
#define FUNC_RND     4
#define FUNC_UNKNOWN 5


static const TU8 TABLE_TO[] PROGMEM = {
    'T','O'+0x80,
    0
};


static const TU8 TABLE_STEP[] PROGMEM = {
    'S','T','E','P'+0x80,
    0
};


static const TU8 TABLE_RELOP[] PROGMEM = {
    '>','='+0x80,
    '<','>'+0x80,
    '>'+0x80,
    '='+0x80,
    '<','='+0x80,
    '<'+0x80,
    '!','='+0x80,
    0
};
#define RELOP_GE		0
#define RELOP_NE		1
#define RELOP_GT		2
#define RELOP_EQ		3
#define RELOP_LE		4
#define RELOP_LT		5
#define RELOP_NE_BANG		6
#define RELOP_UNKNOWN	7


static const TU8 TABLE_HILO[] PROGMEM = {
    'H','I','G','H'+0x80,
    'H','I'+0x80,
    'L','O','W'+0x80,
    'L','O'+0x80,
    0
};
#define HIGHLOW_HIGH    1
#define HIGHLOW_UNKNOWN 4

