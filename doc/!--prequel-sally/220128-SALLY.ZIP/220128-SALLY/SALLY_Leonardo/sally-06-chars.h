//sally-chars.h


static const TChar CR = '\r';
static const TChar NL = '\n';
static const TChar LF = 0x0a;
static const TChar TAB = '\t';
static const TChar BELL = '\b';
static const TChar SPACE = ' ';
static const TChar SQUOTE = '\'';
static const TChar DQUOTE  = '\"';
static const TChar CTRLC	= 0x03;
//#define CTRLH	0x08
//#define CTRLS	0x13
//#define CTRLX	0x18

