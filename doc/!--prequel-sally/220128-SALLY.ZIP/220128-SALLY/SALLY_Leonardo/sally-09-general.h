//sally-general.h


static void SkipWhitespace(void);
static void ScanTable(const TU8 *table);
static TU16 TestNumber(void);
static TU8 *FindLine(void);
static void LineBufferToUppercase(void);


static void SkipWhitespace(void)
{
    while (*txtpos == SPACE || *txtpos == TAB)
        txtpos++;
}


static void ScanTable(const TU8 *table)
{
    TU16 i = 0;
    table_index = 0;

    while (true)
    {
        // Run out of table entries?
        if (pgm_read_byte( table ) == 0)
            return;

        // Do we match this character?
        if (txtpos[i] == pgm_read_byte(table))
        {
            i++;
            table++;
        }
        else
        {
            // do we match the last character of keywork (with 0x80 added)? If so, return
            if (txtpos[i]+0x80 == pgm_read_byte(table))
            {
                txtpos += i+1;  // Advance the pointer to following the keyword
                SkipWhitespace();
                return;
            }

            // Forward to the end of this keyword
            while ((pgm_read_byte(table) & 0x80) == 0)
                table++;

            // Now move on to the first character of the next word, and reset the position index
            table++;
            table_index++;
            SkipWhitespace();
            i = 0;
        }
    }
}


static TU16 TestNumber(void)
{
    TU16 num = 0;
    SkipWhitespace();

    while (*txtpos >= '0' && *txtpos <= '9')
    {
        // Trap overflows
        if (num >= 0xFFFF/10)
        {
            num = 0xFFFF; //mixworx MAX TS16/TU16
            break;
        }

        num = num *10 + *txtpos - '0';
        txtpos++;
    }
    return num;
}


static TU8 *FindLine(void)
{
    TU8 *line = program_start;
    while (true)
    {
        if (line == program_end)
            return line;

        if (((TU16_LineNum *)line)[0] >= linenum)
            return line;

        // Add the line length onto the current address, to get to the next line;
        line += line[sizeof(TU16_LineNum)];
    }
}


static void LineBufferToUppercase(void)
{
    TU8 *c = program_end + sizeof(TU16_LineNum);
    TU8 quote = 0;

    while (*c != NL)
    {
        // Are we in a quoted string?
        if (*c == quote)
            quote = 0;
        else if (*c == '"' || *c == '\'')
            quote = *c;
        else if (quote == 0 && *c >= 'a' && *c <= 'z')
            *c = *c + 'A' - 'a';
        c++;
    }
}

