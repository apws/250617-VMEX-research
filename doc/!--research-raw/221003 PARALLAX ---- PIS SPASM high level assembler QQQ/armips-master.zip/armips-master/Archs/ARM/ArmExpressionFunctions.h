#pragma once

class ExpressionFunctionHandler;

void registerArmExpressionFunctions(ExpressionFunctionHandler &handler);
