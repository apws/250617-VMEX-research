#pragma once

class ExpressionFunctionHandler;

void registerMipsExpressionFunctions(ExpressionFunctionHandler &handler);
