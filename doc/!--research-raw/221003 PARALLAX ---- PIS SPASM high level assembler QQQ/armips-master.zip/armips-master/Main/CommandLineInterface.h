#pragma once

#include "Core/Assembler.h"

int runFromCommandLine(const std::vector<std::string>& arguments, ArmipsArguments settings = {});
