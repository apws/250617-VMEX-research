// No include of FileSystem.h, just include the impl file to define the function implementations
#ifndef ARMIPS_USE_STD_FILESYSTEM
#include <ghc/fs_impl.hpp>
#endif
