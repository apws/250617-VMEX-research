#define SPASM_NG_VERSION "v0.5-beta.3"
