#ifndef __PREOP_H
#define __PREOP_H

#include "storage.h"
char *handle_preop (char *ptr);
char *parse_arg_defs (const char *ptr, define_t *define);

#endif

