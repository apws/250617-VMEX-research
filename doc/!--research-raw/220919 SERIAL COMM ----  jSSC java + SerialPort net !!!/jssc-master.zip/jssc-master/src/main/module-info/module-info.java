@SuppressWarnings({ "requires-automatic", "requires-transitive-automatic" })
open module jssc {
    requires transitive org.scijava.nativelib;
    exports jssc;
}
