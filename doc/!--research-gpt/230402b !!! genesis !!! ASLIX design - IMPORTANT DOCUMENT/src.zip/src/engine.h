
// placeholder to move here as much as possible of shared implementation between C and C# to be included by VMEX.cs
// umm, probably no includes still in C# possible, so we can jsut have engine.c as source and copy it to engine.cs
