<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="zelda_mini_plus_walk" tilewidth="16" tileheight="16" tilecount="136" columns="17">
 <image source="zelda_mini_plus_walk.png" width="272" height="128"/>
</tileset>
