#include "tbman.h"

int main()
{
	tbman_puts("Hello, world!\n");
	tbman_exit(123);
}