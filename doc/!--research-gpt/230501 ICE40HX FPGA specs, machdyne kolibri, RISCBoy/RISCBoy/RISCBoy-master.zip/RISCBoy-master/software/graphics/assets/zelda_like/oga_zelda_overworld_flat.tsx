<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.2" name="oga_zelda_overworld_flat" tilewidth="16" tileheight="16" tilecount="102" columns="17">
 <image source="oga_zelda_overworld_flat.png" width="273" height="97"/>
</tileset>
