Graphics Assets
===============

I did not make any of these -- this is the hard work of real artists, who have published their art online for free use. Authors and licences are listed below.

abandonauts
-----------

Artist: Adam Atomic

Licence: CC0 public domain

Link: [Abandonauts 8x8 tile assets on OpenGameArt](https://opengameart.org/content/abandonauts-8x8-tile-assets)

arcade_platformer
-----------------

Artist: GrafxKid

Licence: CC0 public domain

Link: [Arcade Platformer Assets on OpenGameArt](https://opengameart.org/content/arcade-platformer-assets)

colony
------

Artist: Michele Bucelli

Licence: CC0 public domain

Link [Colony sim assets on OpenGameArt](https://opengameart.org/content/colony-sim-assets)


platformer_art_deluxe_pixel_edition
-----------------------------------

Artist: Kenney.nl

Licence: CC0 public domain

Link: [Platformer Art: Pixel Edition on OpenGameArt](https://opengameart.org/content/platformer-art-pixel-edition)

platformer_in_the_forest
------------------------

Artist: Michele Bucelli

Licence: CC0 public domain

Link [A platformer in the forest on OpenGameArt](https://opengameart.org/content/a-platformer-in-the-forest)


zelda_like
----------

Artist: Armando Montero

Licence: CC0 public domain

Link: [Zelda-like tilesets and sprites on OpenGameArt](https://opengameart.org/content/zelda-like-tilesets-and-sprites)
