RISCBoy Documentation
---------------------

This is written in LaTeX. I usually keep the [latest PDF](riscboy_doc.pdf) up to date. To rebuild:

```bash
$ # Prerequisites (Ubuntu 20.04)
$ sudo apt install texlive texlive-latex-extra texlive-science librsvg2-bin
$ make clean all
$ # Or, to open the PDF after building
$ make clean view
```
