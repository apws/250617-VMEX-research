This example displays 8-bit bitmap images using a 256 colour palette at 1280x720 resolution.

You can create your own image data uf2 to flash to the pico before starting the example using `scripts/builduf2`.  You'll need to have graphicsmagick and uf2conv installed.  uf2conv can be found here: https://github.com/microsoft/uf2/blob/master/utils/uf2conv.py
