This is a .NET Maui application that connects to a HC-05 Bluetooth transceiver on an Arduino board
