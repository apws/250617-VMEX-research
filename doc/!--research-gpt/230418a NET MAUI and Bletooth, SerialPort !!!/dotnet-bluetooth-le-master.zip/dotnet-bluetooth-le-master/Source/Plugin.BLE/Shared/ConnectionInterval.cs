﻿namespace Plugin.BLE.Abstractions
{
    public enum ConnectionInterval
    {
        Normal = 0,
        High = 1,
        Low = 2 
    }
}
