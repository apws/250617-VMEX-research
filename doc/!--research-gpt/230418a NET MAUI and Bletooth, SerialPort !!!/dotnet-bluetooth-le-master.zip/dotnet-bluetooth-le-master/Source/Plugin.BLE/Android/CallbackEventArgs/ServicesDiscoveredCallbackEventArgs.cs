using System;

namespace Plugin.BLE.Android.CallbackEventArgs
{
    public class ServicesDiscoveredCallbackEventArgs : EventArgs
    {
    }
}